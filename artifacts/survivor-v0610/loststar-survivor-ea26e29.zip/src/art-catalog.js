window.SurvivorArtCatalog = {
  "player": {
    "nativeSize": [
      24,
      24
    ],
    "center": [
      12.0,
      12.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        8.5,
        23
      ],
      [
        14.5,
        23
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      12,
      12
    ],
    "collisionRadius": 7,
    "src": "./assets/actors/player@2x.png",
    "sha256": "db12105c3e4eaeae53217512d6ab5edf9602e7893cdc6b8a15dc8d20e3bcfeae",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12.0,
          12.0
        ]
      }
    ]
  },
  "skimmer": {
    "nativeSize": [
      24,
      24
    ],
    "center": [
      12.0,
      12.0
    ],
    "forward": [
      0,
      -1
    ],
    "src": "./assets/actors/skimmer@2x.png",
    "sha256": "808cae887a46d2d23177c5dce7274144e0400a0b35e06379f0a2805dc04ae26f",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12.0,
          12.0
        ]
      }
    ]
  },
  "wisp": {
    "nativeSize": [
      24,
      24
    ],
    "center": [
      12.0,
      12.0
    ],
    "forward": [
      0,
      -1
    ],
    "src": "./assets/actors/wisp@2x.png",
    "sha256": "45b8332b4074e7c5c104cd23a37bbf5b5dd2f2243cdfda382e3924f6f5e74368",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12.0,
          12.0
        ]
      }
    ]
  },
  "ranger": {
    "nativeSize": [
      24,
      24
    ],
    "center": [
      12.0,
      12.0
    ],
    "forward": [
      0,
      -1
    ],
    "src": "./assets/actors/ranger@2x.png",
    "sha256": "7d754bf2f372e6a592e167d384a38a5a5606869ba55ae094849d1c3d60568121",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12.0,
          12.0
        ]
      }
    ]
  },
  "tank": {
    "nativeSize": [
      32,
      32
    ],
    "center": [
      16.0,
      16.0
    ],
    "forward": [
      0,
      -1
    ],
    "src": "./assets/actors/tank@2x.png",
    "sha256": "9b7986b26d86519f8fd60b1f01a53990358b9633be5b672e12bdbcc4fc79fb6f",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 32,
        "height": 32,
        "anchor": [
          16.0,
          16.0
        ]
      }
    ]
  },
  "elite": {
    "nativeSize": [
      36,
      36
    ],
    "center": [
      18.0,
      18.0
    ],
    "forward": [
      0,
      -1
    ],
    "src": "./assets/actors/elite@2x.png",
    "sha256": "f0c35ff3c35b42b1252105e651e29a807a37c9bd4027c4cc5bcb8983c898a96c",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 36,
        "height": 36,
        "anchor": [
          18.0,
          18.0
        ]
      }
    ]
  },
  "boss": {
    "nativeSize": [
      48,
      48
    ],
    "center": [
      24.0,
      24.0
    ],
    "forward": [
      0,
      -1
    ],
    "src": "./assets/actors/boss@2x.png",
    "sha256": "077fdf64918a9693d01ea9b0e041551aea3c4951fc82ed008dfb802b17cbb5c9",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24.0,
          24.0
        ]
      }
    ]
  },
  "cannon": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/cannon@2x.png",
    "sha256": "bd83c47da845adf8faef8d660300b9d98ee34696b32de16c85dcae2b1b50b9eb",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          5,
          3,
          20,
          22
        ]
      }
    ]
  },
  "drone": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/drone@2x.png",
    "sha256": "de0e7f1d1c39fac588dcc233b6ae4744d4756d3144548485b1c4f73e4a8cfe39",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          3,
          21,
          20
        ]
      }
    ]
  },
  "arc": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/arc@2x.png",
    "sha256": "85b5ce994b29c60233314a5828d8b22c970885f13da931b8bbe375397bf587e8",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          2,
          3,
          22,
          21
        ]
      }
    ]
  },
  "missile": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/missile@2x.png",
    "sha256": "3725a97c3712e296a9d5b0fe1739fa5d61576dec8654d895fe5c09d1fe362538",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          4,
          2,
          21,
          22
        ]
      }
    ]
  },
  "blade": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/blade@2x.png",
    "sha256": "761bfd8a8186716c0b078956bde94050bc6d010a9fd61d2765c666fe2eae3ca1",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          3,
          22,
          22
        ]
      }
    ]
  },
  "shield": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/shield@2x.png",
    "sha256": "7882139fa92b6c955964737fea516991e5eb9c27842b23e60ea6f3869d273042",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          2,
          22,
          23
        ]
      }
    ]
  },
  "lens": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/lens@2x.png",
    "sha256": "55ba4bc55cad363fa9cd114502255e4628fa41ff9edecadc41df814eb5684b6d",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          4,
          4,
          21,
          21
        ]
      }
    ]
  },
  "lock": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/lock@2x.png",
    "sha256": "9d21f89051fc4530901df81aaae45eaba2ff87d71349d28b031990d745fef24c",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          3,
          22,
          22
        ]
      }
    ]
  },
  "capacitor": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/capacitor@2x.png",
    "sha256": "b83e58c65c24c465b15928fa15a5b6591d4e013a052eb1a2af3963abe631bb62",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          2,
          3,
          22,
          22
        ]
      }
    ]
  },
  "cooler": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/cooler@2x.png",
    "sha256": "c436aace72b2cef9fee25aae325f474f7957b811797c8b6de51d69ecb54b0c36",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          4,
          22,
          22
        ]
      }
    ]
  },
  "magnet": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/magnet@2x.png",
    "sha256": "3c67c86e7296b980764680274b176cb6dba915a46a30be2211541196d457bc25",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          4,
          4,
          21,
          22
        ]
      }
    ]
  },
  "armor": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/armor@2x.png",
    "sha256": "4265c6d725dbfaae02e0e258e6d05e0137b7d83e6fddac177d8b215bb5144db2",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          3,
          22,
          22
        ]
      }
    ]
  },
  "piercebeam": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/piercebeam@2x.png",
    "sha256": "638ad96abb67680833cf8fb009d67cd374c5cbd68e51b855311d2ccbe0605f29",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          5,
          2,
          20,
          22
        ]
      }
    ]
  },
  "hunterswarm": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/hunterswarm@2x.png",
    "sha256": "f7cd6be3bcffd085ec6037ee221a7b6bd537448fc643f1bec91d7f0903e667eb",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          2,
          3,
          23,
          20
        ]
      }
    ]
  },
  "chainstorm": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/chainstorm@2x.png",
    "sha256": "b9409eb855b4fdc9779c9dcf2e1507d3f4e56558741694e66b6ac72eda30ae57",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          3,
          22,
          22
        ]
      }
    ]
  },
  "meteorbarrage": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/meteorbarrage@2x.png",
    "sha256": "015d034c239507691eea16bcee9710bc8b46321d871c41e7f7291651b1800890",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          2,
          2,
          23,
          22
        ]
      }
    ]
  },
  "spiralsaw": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/spiralsaw@2x.png",
    "sha256": "9442f20c9b42940ab3efd9fb835dcd9e714c29e20271471019fd6cc26162d29d",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          3,
          22,
          22
        ]
      }
    ]
  },
  "reactiveaegis": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/reactiveaegis@2x.png",
    "sha256": "9c58c4e6966c8776968d9a05fa7a14e516cd5830060866f99a657f6019cd081c",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          1,
          2,
          23,
          23
        ]
      }
    ]
  },
  "thunderhive": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/thunderhive@2x.png",
    "sha256": "66b28a7a833af1d1de72879b69281d958d7d7c5d081565571ba11834eb99650d",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          3,
          22,
          22
        ]
      }
    ]
  },
  "blastwheel": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/blastwheel@2x.png",
    "sha256": "2f9331aefdfda661a0c8aa67380e794bba1f33d79ede78448b059ecaaa2d7535",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          2,
          2,
          23,
          23
        ]
      }
    ]
  },
  "xp_crystal": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/xp_crystal@2x.png",
    "sha256": "92df456fddf7ff22bf7a38c96716c4f0c30b1e69b099f72bcc935eb164b24f9d",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          7,
          4,
          18,
          21
        ]
      }
    ]
  },
  "scrap": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/scrap@2x.png",
    "sha256": "f2a8208c9b2134b4266bc657c40064ab528d589ecc26ff0aae133ff33fdd9646",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          4,
          5,
          20,
          21
        ]
      }
    ]
  },
  "pulse": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/pulse@2x.png",
    "sha256": "a8939feaa317b2d7176850770a10bd7a4c5776c8ed377da94e4ad4fd8f16cda5",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          9,
          3,
          16,
          20
        ]
      }
    ]
  },
  "threat": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/threat@2x.png",
    "sha256": "762fc0ae8c4877d4d2156bafd05fa9579f12e74bc45405bb312521264c172432",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          7,
          5,
          18,
          20
        ]
      }
    ]
  },
  "missile_body": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/missile_body@2x.png",
    "sha256": "ce3464f7f5a0f93984bd5037c00b64ddc8b4c0d027fb71d46fa3b9b6b673e024",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          4,
          2,
          21,
          23
        ]
      }
    ]
  },
  "blade_body": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/blade_body@2x.png",
    "sha256": "761bfd8a8186716c0b078956bde94050bc6d010a9fd61d2765c666fe2eae3ca1",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          3,
          22,
          22
        ]
      }
    ]
  },
  "drone_body": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/drone_body@2x.png",
    "sha256": "b62e335a1d9df9766233567f2047eb51318b67b4db847a6d3a08819bb3295251",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          6,
          9,
          19,
          18
        ]
      }
    ]
  },
  "shield_piece": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/shield_piece@2x.png",
    "sha256": "9f8f4e7fa26f64dbbba3b4843ec561b7f05ac3cfa9b44e47c7c3f8d770e18e62",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          4,
          22,
          21
        ]
      }
    ]
  },
  "beam_cap": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/weapons/beam_cap@2x.png",
    "sha256": "08f2fac0a6317241c32db72f6756073b11fbb6d4873c9a04c68104b30384f086",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          4,
          2,
          21,
          23
        ]
      }
    ]
  },
  "explosion": {
    "nativeSize": [
      144,
      24
    ],
    "src": "./assets/weapons/explosion@2x.png",
    "sha256": "544b70e9a41bd2b5fd07d5c474b6b1e42e8acca646f5389574ce809f1c63f225",
    "kind": "atlas",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          10,
          11,
          14,
          13
        ],
        "durationMs": 65
      },
      {
        "x": 24,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          7,
          7,
          17,
          15
        ],
        "durationMs": 65
      },
      {
        "x": 48,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          4,
          20,
          19
        ],
        "durationMs": 65
      },
      {
        "x": 72,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          2,
          2,
          22,
          21
        ],
        "durationMs": 65
      },
      {
        "x": 96,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          4,
          5,
          19,
          19
        ],
        "durationMs": 65
      },
      {
        "x": 120,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          6,
          6,
          18,
          11
        ],
        "durationMs": 65
      }
    ]
  },
  "hit": {
    "nativeSize": [
      96,
      24
    ],
    "src": "./assets/weapons/hit@2x.png",
    "sha256": "5e944ca51ab8d2539bd995d9cd2f7e23c95c0e54a4c847c3c2700446235cda17",
    "kind": "atlas",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          10,
          7,
          17,
          14
        ],
        "durationMs": 45
      },
      {
        "x": 24,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          7,
          6,
          20,
          18
        ],
        "durationMs": 45
      },
      {
        "x": 48,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          5,
          4,
          22,
          21
        ],
        "durationMs": 45
      },
      {
        "x": 72,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          4,
          3,
          22,
          22
        ],
        "durationMs": 45
      }
    ]
  },
  "thruster": {
    "nativeSize": [
      96,
      24
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "nozzleAnchor": [
      12,
      3
    ],
    "shipForward": [
      0,
      -1
    ],
    "src": "./assets/weapons/thruster@2x.png",
    "sha256": "551750182511b0d10f31c27dc781681e4993a41d01b009323ee6918eb11559ce",
    "kind": "atlas",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          7,
          3,
          18,
          19
        ],
        "durationMs": 65,
        "nozzleAnchor": [
          12,
          3
        ],
        "exhaustDirection": [
          0,
          1
        ]
      },
      {
        "x": 24,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          7,
          3,
          18,
          22
        ],
        "durationMs": 65,
        "nozzleAnchor": [
          12,
          3
        ],
        "exhaustDirection": [
          0,
          1
        ]
      },
      {
        "x": 48,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          7,
          3,
          18,
          20
        ],
        "durationMs": 65,
        "nozzleAnchor": [
          12,
          3
        ],
        "exhaustDirection": [
          0,
          1
        ]
      },
      {
        "x": 72,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          7,
          3,
          18,
          23
        ],
        "durationMs": 65,
        "nozzleAnchor": [
          12,
          3
        ],
        "exhaustDirection": [
          0,
          1
        ]
      }
    ]
  },
  "prism": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/v061/prism@2x.png",
    "sha256": "a1aa2fd4bc8375442e03b70629e30fa1ad44c3261790c55b49ef274b3b33fb59",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          1,
          22,
          23
        ]
      }
    ]
  },
  "gravity": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/v061/gravity@2x.png",
    "sha256": "d8459475b2d5232aaab11e67ab89b9ba2ae84e8e87372b309d73d9b2afabe7bf",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          2,
          2,
          23,
          23
        ]
      }
    ]
  },
  "refraction": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/v061/refraction@2x.png",
    "sha256": "bde465db80f5b3cc8b1c7a1184786195e5231b5eda05bec11ef48c1be1e5dea0",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          2,
          2,
          22,
          22
        ]
      }
    ]
  },
  "singularity": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/v061/singularity@2x.png",
    "sha256": "188adcf805877d80f33aec0015e2031308df33a27365da6a0843d4d73ef581be",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          2,
          3,
          23,
          22
        ]
      }
    ]
  },
  "kaleidoscope": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/v061/kaleidoscope@2x.png",
    "sha256": "66f21e10f7bf63c587d67500cfec9fec386fe469ee853015cad389fc0cb87a01",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          2,
          22,
          23
        ]
      }
    ]
  },
  "collapse": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/v061/collapse@2x.png",
    "sha256": "7cfc4bec55cc4670046179f592aef3b2c44d2ecb405315d290f359b14966f8f2",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          3,
          2,
          22,
          23
        ]
      }
    ]
  },
  "eventhorizon": {
    "nativeSize": [
      24,
      24
    ],
    "src": "./assets/v061/eventhorizon@2x.png",
    "sha256": "aae96d0f8555c52fd5c4248b6eba1a9ef89314fb696d99ecedae4b39c8e2c3e9",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          12
        ],
        "bounds": [
          2,
          1,
          23,
          23
        ]
      }
    ]
  },
  "rail_muzzle": {
    "nativeSize": [
      144,
      24
    ],
    "durationMs": 180,
    "originAnchor": [
      12,
      17
    ],
    "emissionDirection": [
      0,
      -1
    ],
    "src": "./assets/v061/rail_muzzle@2x.png",
    "sha256": "86ce889ee304b35c701919caa201200365c5331414780d6f20bc580377717cd5",
    "kind": "atlas",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          17
        ],
        "bounds": [
          10,
          15,
          14,
          18
        ],
        "durationMs": 28
      },
      {
        "x": 24,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          17
        ],
        "bounds": [
          8,
          8,
          15,
          18
        ],
        "durationMs": 35
      },
      {
        "x": 48,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          17
        ],
        "bounds": [
          6,
          4,
          18,
          18
        ],
        "durationMs": 45
      },
      {
        "x": 72,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          17
        ],
        "bounds": [
          5,
          4,
          19,
          18
        ],
        "durationMs": 30
      },
      {
        "x": 96,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          17
        ],
        "bounds": [
          7,
          6,
          16,
          18
        ],
        "durationMs": 22
      },
      {
        "x": 120,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12,
          17
        ],
        "bounds": [
          10,
          12,
          14,
          18
        ],
        "durationMs": 20
      }
    ]
  },
  "gravity_burst": {
    "nativeSize": [
      288,
      48
    ],
    "durationMs": 480,
    "src": "./assets/v061/gravity_burst@2x.png",
    "sha256": "80f5144f345d80b927e8dce17556adee3472d2f33463aa18491b60ab93d9ad1c",
    "kind": "atlas",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          19,
          19,
          29,
          28
        ],
        "durationMs": 55
      },
      {
        "x": 48,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          11,
          11,
          37,
          37
        ],
        "durationMs": 80
      },
      {
        "x": 96,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          3,
          3,
          46,
          44
        ],
        "durationMs": 95
      },
      {
        "x": 144,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          8,
          8,
          41,
          40
        ],
        "durationMs": 100
      },
      {
        "x": 192,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          15,
          14,
          33,
          34
        ],
        "durationMs": 85
      },
      {
        "x": 240,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          16,
          19,
          30,
          29
        ],
        "durationMs": 65
      }
    ]
  },
  "evolution_corona": {
    "nativeSize": [
      288,
      48
    ],
    "durationMs": 580,
    "src": "./assets/v061/evolution_corona@2x.png",
    "sha256": "80ede63e36084a291a0763cc5b740ed84030ba5917289c6a01f05b0574df4a78",
    "kind": "atlas",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          16,
          17,
          32,
          32
        ],
        "durationMs": 70
      },
      {
        "x": 48,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          12,
          11,
          36,
          36
        ],
        "durationMs": 95
      },
      {
        "x": 96,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          5,
          5,
          43,
          42
        ],
        "durationMs": 130
      },
      {
        "x": 144,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          6,
          6,
          42,
          39
        ],
        "durationMs": 110
      },
      {
        "x": 192,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          11,
          10,
          36,
          36
        ],
        "durationMs": 95
      },
      {
        "x": 240,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          17,
          16,
          31,
          30
        ],
        "durationMs": 80
      }
    ]
  },
  "fusion_nova": {
    "nativeSize": [
      288,
      48
    ],
    "durationMs": 600,
    "src": "./assets/v061/fusion_nova@2x.png",
    "sha256": "df4f1bc89a22c29ebf3283607d26dda0c022f07a54b6e2e5e30075997e11a18f",
    "kind": "atlas",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          11,
          17,
          38,
          30
        ],
        "durationMs": 70
      },
      {
        "x": 48,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          9,
          15,
          38,
          33
        ],
        "durationMs": 95
      },
      {
        "x": 96,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          10,
          12,
          37,
          34
        ],
        "durationMs": 135
      },
      {
        "x": 144,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          5,
          4,
          44,
          39
        ],
        "durationMs": 115
      },
      {
        "x": 192,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          10,
          9,
          38,
          34
        ],
        "durationMs": 95
      },
      {
        "x": 240,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24,
          24
        ],
        "bounds": [
          15,
          14,
          32,
          30
        ],
        "durationMs": 90
      }
    ]
  },
  "lancer": {
    "nativeSize": [
      28,
      28
    ],
    "center": [
      14.0,
      14.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        11,
        23
      ],
      [
        16,
        23
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      14.0,
      14.0
    ],
    "collisionRadius": 7,
    "src": "./assets/v062/actors/lancer@2x.png",
    "sha256": "a7e2941750c9400ca1ec96c3da39b69f6d57ab9487fe7ef608b6a36753d3769d",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 28,
        "height": 28,
        "anchor": [
          14.0,
          14.0
        ]
      }
    ]
  },
  "sentinel": {
    "nativeSize": [
      32,
      32
    ],
    "center": [
      16.0,
      16.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        10,
        29
      ],
      [
        22,
        29
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      16.0,
      16.0
    ],
    "collisionRadius": 11,
    "src": "./assets/v062/actors/sentinel@2x.png",
    "sha256": "87585b555480978ada2b6660c31485a57823fcc8fc31cc8a0333cadef583fa83",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 32,
        "height": 32,
        "anchor": [
          16.0,
          16.0
        ]
      }
    ]
  },
  "minelayer": {
    "nativeSize": [
      32,
      32
    ],
    "center": [
      16.0,
      16.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        12,
        25
      ],
      [
        20,
        25
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      16.0,
      16.0
    ],
    "collisionRadius": 11,
    "src": "./assets/v062/actors/minelayer@2x.png",
    "sha256": "3e13bfabdede7a6cd4f540f6b186dff594b8d5818a332c883cafef68fd38b97e",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 32,
        "height": 32,
        "anchor": [
          16.0,
          16.0
        ]
      }
    ]
  },
  "courier": {
    "nativeSize": [
      32,
      32
    ],
    "center": [
      16.0,
      16.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        5,
        22
      ],
      [
        26,
        22
      ],
      [
        16,
        30
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      16.0,
      16.0
    ],
    "collisionRadius": 12,
    "src": "./assets/v062/actors/courier@2x.png",
    "sha256": "decf45cfa83b808b634fa9c061ab04cc0dcc6ddd3047de9264e8eca7f642b4c9",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 32,
        "height": 32,
        "anchor": [
          16.0,
          16.0
        ]
      }
    ]
  },
  "watcher": {
    "nativeSize": [
      40,
      40
    ],
    "center": [
      20.0,
      20.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        19,
        33
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      20.0,
      20.0
    ],
    "collisionRadius": 15,
    "src": "./assets/v062/actors/watcher@2x.png",
    "sha256": "274e8a2f3ea663d469186815fb53917b835ba0d5635e97a0a434b67c72af1e7d",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 40,
        "height": 40,
        "anchor": [
          20.0,
          20.0
        ]
      }
    ]
  },
  "deep_space": {
    "nativeSize": [
      384,
      640
    ],
    "center": [
      192,
      320
    ],
    "src": "./assets/v062/space/deep_space@2x.png",
    "sha256": "fed3ee5844a08915d82e5cb41800d029187feb2e0ed2e21fbd4595ddac79dcf9",
    "kind": "background",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 384,
        "height": 640,
        "anchor": [
          192,
          320
        ]
      }
    ]
  },
  "elite_raider": {
    "nativeSize": [
      40,
      40
    ],
    "center": [
      20.0,
      20.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        11.5,
        38
      ],
      [
        27.5,
        38
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      20.0,
      20.0
    ],
    "collisionRadius": 14,
    "src": "./assets/v064/actors/elite_raider@2x.png",
    "sha256": "1efaa114eb249332819c93f166f63d8a561f3b0be27bbed3f3ed7b9b06d180da",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 40,
        "height": 40,
        "anchor": [
          20.0,
          20.0
        ]
      }
    ]
  },
  "elite_warden": {
    "nativeSize": [
      48,
      48
    ],
    "center": [
      24.0,
      24.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        11.5,
        37
      ],
      [
        35.5,
        37
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      24.0,
      24.0
    ],
    "collisionRadius": 13,
    "src": "./assets/v064/actors/elite_warden@2x.png",
    "sha256": "219c721ce4ea09658d98499f42b1e7959431242407a95e1346559c286004e9aa",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24.0,
          24.0
        ]
      }
    ]
  },
  "prism_crystal": {
    "nativeSize": [
      16,
      24
    ],
    "center": [
      8,
      12
    ],
    "forward": [
      0,
      -1
    ],
    "src": "./assets/v064/weapons/prism_crystal@2x.png",
    "sha256": "a32512d81751380ce03c7561508b4f46c1b57fe88ac75a100394f240817809ac",
    "kind": "effect",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 16,
        "height": 24,
        "anchor": [
          8,
          12
        ]
      }
    ]
  },
  "boss_weaver": {
    "nativeSize": [
      64,
      64
    ],
    "center": [
      32.0,
      32.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        25,
        57
      ],
      [
        39,
        57
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      32.0,
      32.0
    ],
    "collisionRadius": 7,
    "collisionCircles": [
      {
        "part": "core",
        "x": 32,
        "y": 30,
        "r": 6
      },
      {
        "part": "left_emitter",
        "x": 18,
        "y": 11,
        "r": 4
      },
      {
        "part": "left_upper_arm",
        "x": 12,
        "y": 22,
        "r": 5
      },
      {
        "part": "left_lower_arm",
        "x": 13,
        "y": 37,
        "r": 5
      },
      {
        "part": "left_joint",
        "x": 20,
        "y": 46,
        "r": 5
      },
      {
        "part": "right_emitter",
        "x": 46,
        "y": 11,
        "r": 4
      },
      {
        "part": "right_upper_arm",
        "x": 52,
        "y": 22,
        "r": 5
      },
      {
        "part": "right_lower_arm",
        "x": 51,
        "y": 37,
        "r": 5
      },
      {
        "part": "right_joint",
        "x": 44,
        "y": 46,
        "r": 5
      },
      {
        "part": "lower_bridge",
        "x": 32,
        "y": 48,
        "r": 6
      }
    ],
    "shotNozzles": [
      [
        18,
        8
      ],
      [
        46,
        8
      ]
    ],
    "src": "./assets/v065/bosses/boss_weaver@2x.png",
    "sha256": "2fea428b0bbd8880f0d88a3726a4a74af24229e4755bb6ebd08964b285913566",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 64,
        "height": 64,
        "anchor": [
          32.0,
          32.0
        ]
      }
    ]
  },
  "boss_ark": {
    "nativeSize": [
      64,
      64
    ],
    "center": [
      32.0,
      32.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        18,
        52
      ],
      [
        46,
        52
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      32.0,
      32.0
    ],
    "collisionRadius": 8,
    "collisionCircles": [
      {
        "part": "command_deck",
        "x": 32,
        "y": 34,
        "r": 8
      },
      {
        "part": "left_magazines",
        "x": 17,
        "y": 34,
        "r": 9
      },
      {
        "part": "right_magazines",
        "x": 47,
        "y": 34,
        "r": 9
      },
      {
        "part": "left_bow",
        "x": 23,
        "y": 21,
        "r": 5
      },
      {
        "part": "right_bow",
        "x": 41,
        "y": 21,
        "r": 5
      },
      {
        "part": "left_engine",
        "x": 18,
        "y": 45,
        "r": 5
      },
      {
        "part": "right_engine",
        "x": 46,
        "y": 45,
        "r": 5
      }
    ],
    "launcherAnchors": [
      [
        10,
        32
      ],
      [
        17,
        32
      ],
      [
        24,
        32
      ],
      [
        40,
        32
      ],
      [
        47,
        32
      ],
      [
        54,
        32
      ]
    ],
    "shotNozzles": [
      [
        32,
        24
      ]
    ],
    "src": "./assets/v065/bosses/boss_ark@2x.png",
    "sha256": "7f6d3ed18e337dc88e708c41aaf14ed55db17bd683a629521ad860d7c8702196",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 64,
        "height": 64,
        "anchor": [
          32.0,
          32.0
        ]
      }
    ]
  },
  "boss_judicator": {
    "nativeSize": [
      64,
      64
    ],
    "center": [
      32.0,
      32.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        18,
        61
      ],
      [
        46,
        61
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      32.0,
      32.0
    ],
    "collisionRadius": 5,
    "collisionCircles": [
      {
        "part": "bridge_core",
        "x": 32,
        "y": 34,
        "r": 5
      },
      {
        "part": "left_forward_spine",
        "x": 18,
        "y": 14,
        "r": 6
      },
      {
        "part": "left_mid_spine",
        "x": 18,
        "y": 28,
        "r": 7
      },
      {
        "part": "left_aft_spine",
        "x": 18,
        "y": 43,
        "r": 6
      },
      {
        "part": "left_engine",
        "x": 18,
        "y": 54,
        "r": 5
      },
      {
        "part": "right_forward_spine",
        "x": 46,
        "y": 14,
        "r": 6
      },
      {
        "part": "right_mid_spine",
        "x": 46,
        "y": 28,
        "r": 7
      },
      {
        "part": "right_aft_spine",
        "x": 46,
        "y": 43,
        "r": 6
      },
      {
        "part": "right_engine",
        "x": 46,
        "y": 54,
        "r": 5
      }
    ],
    "shotNozzles": [
      [
        18,
        5
      ],
      [
        46,
        5
      ]
    ],
    "src": "./assets/v065/bosses/boss_judicator@2x.png",
    "sha256": "8a930afa12e78fb66524b500d28ea0769e5952d20d813ee306023048e957605e",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 64,
        "height": 64,
        "anchor": [
          32.0,
          32.0
        ]
      }
    ]
  },
  "elite_reaver": {
    "nativeSize": [
      40,
      40
    ],
    "center": [
      20.0,
      20.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        17.5,
        31
      ],
      [
        22.5,
        31
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      20.0,
      20.0
    ],
    "collisionRadius": 11,
    "weaponAnchors": [
      [
        6.5,
        7.5
      ],
      [
        33.5,
        7.5
      ]
    ],
    "src": "./assets/v065/elites/elite_reaver@2x.png",
    "sha256": "976a5f0dac600e871f38fccb7b3913cd8cea498e4a710cb9940bdd7d23a2545a",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 40,
        "height": 40,
        "anchor": [
          20.0,
          20.0
        ]
      }
    ]
  },
  "elite_hive": {
    "nativeSize": [
      48,
      40
    ],
    "center": [
      24.0,
      20.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        19.5,
        39
      ],
      [
        27.5,
        39
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionCenter": [
      24.0,
      20.0
    ],
    "collisionRadius": 14,
    "weaponAnchors": [
      [
        8,
        14
      ],
      [
        39,
        14
      ]
    ],
    "launchAnchors": [
      [
        8,
        15.5
      ],
      [
        39,
        15.5
      ],
      [
        8,
        23.5
      ],
      [
        39,
        23.5
      ]
    ],
    "src": "./assets/v065/elites/elite_hive@2x.png",
    "sha256": "dd649e6c9ff7662296ab0cb6e1d865a45b03e47a40319a7b25dccbcb83b0dbd7",
    "kind": "actor",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 48,
        "height": 40,
        "anchor": [
          24.0,
          20.0
        ]
      }
    ]
  },
  "hunter_drone": {
    "nativeSize": [
      28,
      28
    ],
    "center": [
      14.0,
      14.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        12,
        23
      ],
      [
        16,
        23
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionRadius": 9,
    "muzzleAnchors": [
      [
        10.5,
        4.5
      ],
      [
        17.5,
        4.5
      ]
    ],
    "src": "./assets/v065/weapons/hunter_drone@2x.png",
    "sha256": "09cc7ef68e6aff96bef1e2204be60ff2d4adbdb70631c6eaa10b5a93578e6974",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 28,
        "height": 28,
        "anchor": [
          14.0,
          14.0
        ]
      }
    ]
  },
  "hive_drone": {
    "nativeSize": [
      32,
      28
    ],
    "center": [
      16.0,
      14.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [
      [
        14,
        20
      ],
      [
        18,
        20
      ]
    ],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionRadius": 9,
    "muzzleAnchors": [
      [
        14.5,
        7.5
      ],
      [
        17.5,
        7.5
      ]
    ],
    "src": "./assets/v065/weapons/hive_drone@2x.png",
    "sha256": "7cea71ce5cb37d6f64414b6f999cc7166cf8953f286edda888e85e90940d4365",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 32,
        "height": 28,
        "anchor": [
          16.0,
          14.0
        ]
      }
    ]
  },
  "bastion_mount": {
    "nativeSize": [
      40,
      40
    ],
    "center": [
      20.0,
      20.0
    ],
    "forward": [
      0,
      -1
    ],
    "exhaustAnchors": [],
    "exhaustDirection": [
      0,
      1
    ],
    "collisionRadius": 0,
    "originAnchor": [
      20,
      20
    ],
    "muzzleAnchors": [
      [
        7.5,
        2.5
      ],
      [
        32.5,
        2.5
      ]
    ],
    "src": "./assets/v065/weapons/bastion_mount@2x.png",
    "sha256": "bc51bb6e5f2230e937082a4c20443d3b2bde8ee3fbd0d6ba37cecec340bd7a3b",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 40,
        "height": 40,
        "anchor": [
          20.0,
          20.0
        ]
      }
    ]
  },
  "ionbastion": {
    "nativeSize": [
      24,
      24
    ],
    "center": [
      12.0,
      12.0
    ],
    "forward": [
      0,
      -1
    ],
    "collisionRadius": 0,
    "src": "./assets/v065/weapons/ionbastion@2x.png",
    "sha256": "4c8b4d9599176fa92a2bf20e76cf899797ba3c27d4c397619cf9339626c87255",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12.0,
          12.0
        ]
      }
    ]
  },
  "repair_pod": {
    "nativeSize": [
      28,
      24
    ],
    "center": [
      14.0,
      12.0
    ],
    "forward": [
      0,
      -1
    ],
    "collisionRadius": 0,
    "originAnchor": [
      14,
      13
    ],
    "launchAnchors": [
      [
        5,
        5
      ],
      [
        22,
        5
      ]
    ],
    "src": "./assets/v067/repair/repair_pod@2x.png",
    "sha256": "1e9c74edc24c1d0a5e120b9218c869dc7fd63a79e4e5b3800657f618957fb2bf",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 28,
        "height": 24,
        "anchor": [
          14.0,
          12.0
        ]
      }
    ]
  },
  "repairpod": {
    "nativeSize": [
      24,
      24
    ],
    "center": [
      12.0,
      12.0
    ],
    "forward": [
      0,
      -1
    ],
    "collisionRadius": 0,
    "src": "./assets/v067/repair/repairpod@2x.png",
    "sha256": "54794c3228b3e8e323ac994d2338620999730a24d221a3f758e02be7490f1b6d",
    "kind": "icon",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 24,
        "height": 24,
        "anchor": [
          12.0,
          12.0
        ]
      }
    ]
  },
  "eventhorizon_core": {
    "nativeSize": [
      64,
      64
    ],
    "center": [
      32.0,
      32.0
    ],
    "forward": [
      0,
      -1
    ],
    "collisionRadius": 0,
    "src": "./assets/v068/fusion/eventhorizon_core@2x.png",
    "sha256": "ce5d14337edf49e5e0296ca926aca4b1de39ec84913c5df996ec17c646c7019a",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 64,
        "height": 64,
        "anchor": [
          32.0,
          32.0
        ]
      }
    ]
  },
  "eventhorizon_ring": {
    "nativeSize": [
      64,
      64
    ],
    "center": [
      32.0,
      32.0
    ],
    "forward": [
      0,
      -1
    ],
    "collisionRadius": 0,
    "src": "./assets/v068/fusion/eventhorizon_ring@2x.png",
    "sha256": "91c8e23a55157f184e8abf78c7ebca0ef142a8dfe99bcdc7b0e68a89346f0ef5",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 64,
        "height": 64,
        "anchor": [
          32.0,
          32.0
        ]
      }
    ]
  },
  "thunder_relay": {
    "nativeSize": [
      40,
      40
    ],
    "center": [
      20.0,
      20.0
    ],
    "forward": [
      0,
      -1
    ],
    "collisionRadius": 0,
    "originAnchor": [
      20,
      20
    ],
    "src": "./assets/v068/fusion/thunder_relay@2x.png",
    "sha256": "f760786a4464b04a69d8caeeacd88b027d236339bc43c063ef0ebb4ed0178174",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 40,
        "height": 40,
        "anchor": [
          20.0,
          20.0
        ]
      }
    ]
  },
  "blastwheel_hub": {
    "nativeSize": [
      48,
      48
    ],
    "center": [
      24.0,
      24.0
    ],
    "forward": [
      0,
      -1
    ],
    "collisionRadius": 0,
    "originAnchor": [
      24,
      24
    ],
    "src": "./assets/v068/fusion/blastwheel_hub@2x.png",
    "sha256": "8eb586613d20ff6e83b2bc783b416ad9ea3591cd78f38312aed240a70d588750",
    "kind": "sprite",
    "frames": [
      {
        "x": 0,
        "y": 0,
        "width": 48,
        "height": 48,
        "anchor": [
          24.0,
          24.0
        ]
      }
    ]
  }
};
