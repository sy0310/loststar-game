window.SurvivorBalance = {
  "version": "0.6.1",
  "runSeconds": 600,
  "eliteAt": 70,
  "bossAt": 130,
  "firstLevelXP": 112,
  "activeSlots": 6,
  "passiveSlots": 6,
  "activeMaxLevel": 3,
  "passiveMaxLevel": 2,
  "hullUpgradeBase": 70,
  "gunUpgradeBase": 90,
  "permanentMaxLevel": 3,
  "maxEnemies": 40,
  "maxFriendlyShots": 72,
  "maxEnemyShots": 56,
  "maxPickups": 140,
  "maxParticles": 160,
  "maxDamageNumbers": 28,
  "maxArcs": 24,
  "maxRings": 24,
  "maxBursts": 28,
  "maxChainTargets": 4,
  "checkpointSeconds": 2,
  "profileKey": "loststar.survivor.prototype.v01",
  "database": "loststar.survivor.demo.v06",
  "levelXP": {
    "base": 80,
    "linear": 38,
    "power": 1.4,
    "powerScale": 8
  },
  "milestones": [
    {
      "at": 70,
      "type": "elite",
      "tier": 1
    },
    {
      "at": 130,
      "type": "boss",
      "tier": 1
    },
    {
      "at": 220,
      "type": "elite",
      "tier": 2
    },
    {
      "at": 310,
      "type": "boss",
      "tier": 2
    },
    {
      "at": 400,
      "type": "elite",
      "tier": 3
    },
    {
      "at": 490,
      "type": "elite",
      "tier": 3
    },
    {
      "at": 550,
      "type": "boss",
      "tier": 3
    }
  ],
  "enemyHealthTimeScale": 200
};
